export interface CompletionMessage {
  role: string
  content: string
}
