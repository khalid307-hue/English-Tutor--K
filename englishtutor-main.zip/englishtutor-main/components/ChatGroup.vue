<template>
  <section class="flex flex-col gap-4">
    <slot></slot>
  </section>
</template>
