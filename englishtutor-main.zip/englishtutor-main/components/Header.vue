<template>
  <div class="p-5 font-bold flex justify-center items-center">🍕English tutor</div>
</template>
